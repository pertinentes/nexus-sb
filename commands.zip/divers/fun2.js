const { language } = require("../../fonctions");

module.exports = {
  name: "rps",
  description: "Play rock-paper-scissors",
  run: async (client, message, args, db, prefix) => {
    // Votre code pour jouer à pierre-papier-ciseaux ici
  }
};
