const Discord = require("discord.js-selfbot-v13");
const { language } = require("../../fonctions");

module.exports = {
  name: "help",
  description: "Menu d'aide",
  run: async (client, message, args, db, prefix) => {
    const botName = db.botname || 'NEXUS';

    message.edit(await language(client, `
♡ **${botName}**

> \`${prefix}panel\` ➜ **Créer le panel**
> \`${prefix}backups\` ➜ **Commandes de backup**
> \`${prefix}divers\` ➜ **Commandes diverses**
> \`${prefix}utils\` ➜ **Commandes utilitaires**
> \`${prefix}guild\` ➜ **Commandes de serveur**「premium」
> \`${prefix}tools\` ➜ **Commandes d'outils**
> \`${prefix}token\` ➜ **Commandes de tokens**
> \`${prefix}raid\` ➜ **Commandes de raid** 「premium」
> \`${prefix}mod\` ➜ **Commandes de modération**
> \`${prefix}fun\` ➜ **Commandes de fun**
> \`${prefix}voice\` ➜ **Commandes vocales**
> \`${prefix}fun2\` ➜ **Commandes de fun supplémentaires**
> \`${prefix}settings\` ➜ **Paramètres pour le selfbot**
> \`${prefix}configrpc\` ➜ **Modifier votre statut RPC**`));
  }
};
