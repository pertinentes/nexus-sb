const fs = require('fs');

module.exports = {
    name: "nexus",
    description: "Envoie le lien de connexion vers Nexus.",
    run: async (client, message, args) => {
        try {
            // Envoie le lien de connexion
            const nexusLink = "https://nexus-sb.online/";
            await message.channel.send(`Voici le lien de connexion vers Nexus : ${nexusLink}`);
        } catch (e) {
            console.error(e);
            message.channel.send("Une erreur s'est produite lors de l'exécution de la commande. Vérifiez la console pour plus d'informations.");
        }
    }
};
