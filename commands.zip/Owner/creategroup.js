const Discord = require('discord.js-selfbot-v13');

const chalk = require('chalk');

module.exports = {

  name: 'creategroup',

  description: 'Créer un groupe DM avec l’utilisateur et le renommer Nexus automatiquement',

  run: async (client, message) => {

    try {

      // L'utilisateur qui lance la commande

      const userId = message.author.id;

      // Créer un groupe DM avec l'utilisateur lui-même

      const groupDM = await client.channels.createDMGroup([userId]);

      

      // Si le groupe DM est créé avec succès, on le renomme

      await groupDM.edit({

        name: 'Nexus' // Nouveau nom du groupe

      });

      // Envoyer un message de confirmation dans le groupe

      await groupDM.send(`

        **Bienvenue sur le panel Nexus** 🌟

        

        **Prefix :** &

        ➤ Ce panel se crée lors de la connexion pour vous permettre de l'utiliser avec le selfbot Nexus.

        ➤ Évitez les commandes publiques, car les utilisateurs peuvent vous signaler.

        ➤ Si vous rencontrez des problèmes, contactez-nous via les commandes d'assistance.

        N'hésitez pas à laisser un avis. 😄

      `);

      console.log(chalk.green(`Groupe DM créé et renommé en Nexus pour l'utilisateur ${userId}.`));

    } catch (error) {

      console.error(chalk.red('Erreur lors de la création et du renommage du groupe DM :'), error);

      message.reply('Une erreur est survenue lors de la création et du renommage du groupe.');

    }

  },

};