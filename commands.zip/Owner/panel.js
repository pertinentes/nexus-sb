const Discord = require("safeness-sb");
const fs = require("fs");
const path = require("path");

module.exports = {
    name: "panel",
    description: "command panel",

    async run(client, message, args) {
        const userId = message.author.id;
        const dbPath = path.join('/home/container/db/', `${userId}.json`);

        if (!fs.existsSync(dbPath)) {
            return message.edit("La base de données de l'utilisateur n'existe pas.");
        }

        const db = JSON.parse(fs.readFileSync(dbPath, 'utf8'));

        client.channels.createGroupDM([Discord.User]).then((grp) => {
            grp.setIcon("https://cdn.discordapp.com/icons/1265595157819166730/db104247fbe53e1e7207b78ab1ad88b9.webp")
            .then(() => grp.setName(`Panel - Nexus`))
            .then((PartialGroupDMChannel) => {
                setTimeout(() => {
                    PartialGroupDMChannel.send(`Bienvenue sur le panel 〃 **NEXUS** 
                    
▸  ***Prefixe*** : \`&\`
          
▸ Ce panel est créé lors de la connexion a NEXUS afin d'utiliser les commandes ici.
          
▸ Il vous ait déconseiller d'utiliser les commandes publiquements, vous pouvez si vous le souhaité.
          
Si vous rencontrez des problèmes lors de l’utilisation de Nexus, rendez-vous ici :
                                      
[**SERVEUR SUPPORT**](<https://discord.gg/nexusv3>)
                                      
▸ N’hésitez pas à nous laisser un <#1289885162766864499>`).then((msg) => {
                        msg.react("⚡");
                        msg.pin();
                    });
                }, 500);
            });
            message.edit("✅ Panel créé avec succès");
        });
    }
}
